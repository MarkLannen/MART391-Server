The BotDetect ASP.NET CAPTCHA NuGet package has been added to your project.

1. You can find what is new in the latest release here:
   https://captcha.com/captcha-roadmap-and-release-notes.html#aspnet_current_release

2. Captcha integration instructions:
   https://captcha.com/asp.net-captcha.html

3. You can download BotDetect ASP.NET Captcha code examples here:
   https://captcha.com/captcha-download.html?version=aspnet